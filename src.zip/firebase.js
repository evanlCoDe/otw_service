// firebase.js
import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

// const firebaseConfig = {
//   apiKey: "你的 API KEY",
//   authDomain: "your-app.firebaseapp.com",
//   projectId: "your-app-id",
//   storageBucket: "your-app.appspot.com",
//   messagingSenderId: "xxx",
//   appId: "xxx",
// };

const firebaseConfig = {
    apiKey: "AIzaSyAlxnglEVsfwkYEmca0NanV9GdXPhdTvk4",
    authDomain: "otw-test-7fd8c.firebaseapp.com",
    projectId: "otw-test-7fd8c",
    storageBucket: "otw-test-7fd8c.firebasestorage.app",
    messagingSenderId: "467493161012",
    appId: "1:467493161012:web:454ed803c496d4274ca261"
  };

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const provider = new GoogleAuthProvider();
export const db = getFirestore(app);
